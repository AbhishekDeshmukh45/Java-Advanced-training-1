
public class program10 {

    public static void main(String[] args) {
    	
        String str1 = "pqr";
        String str2 = "lmno";

        String str3 = "plmrqon";
    
        validShuffle(str1, str2, str3);

    }

    private static void validShuffle(String str1, String str2, String str3) {
        
        String str4 = str1 + str2;
        StringBuffer s = new StringBuffer(str4);

        boolean flag = false;

        char[] ch = str3.toCharArray();

        if (s.length() != str3.length()) {
            flag = false;
        } else {

            for (int i = 0; i < ch.length; i++) {
                
                String temp = Character.toString(ch[i]);

                if (str4.contains(temp)) {

                    s = s.deleteCharAt(s.indexOf(temp));
                    str4 = new String(s);
                    flag = true;
                    
                } else {
                    flag = false;
                    break;
                }

            }

        }

        if (flag) {
            System.out.println("true: Third string is valid suffle of first and second String  ");
        } else {
            System.out.println("false: Third string is not valid suffle of first and second String ");
        }

    }

}