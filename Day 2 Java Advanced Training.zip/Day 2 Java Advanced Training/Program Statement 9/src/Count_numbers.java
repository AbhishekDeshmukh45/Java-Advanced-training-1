
import java.io.*;
import java.util.*;
class Countnumber
{

  static void findFrequency(int [] arr,
                            int n)
  {
    Map<Integer, Integer> a
      = new HashMap<Integer, Integer>();
 
    
    for (int i = 0; i < n; i++)
    	
    {
    	
      
      if (!a.containsKey(arr[i]))
        a.put(arr[i],0);
 
      a.put(arr[i],a.get(arr[i])+1);
      
    }
    
    for (Map.Entry<Integer, Integer>B : a.entrySet())
    	
    {
      System.out.println( B.getKey() +
                         " occurs " + B.getValue() +
                         " times");
    }
  }
 
  
  public static void main (String[] args) 
  {
 
 
    int [] arr = {2,2,2,4,4,4,5,5,6,8,8,9};
    int n = arr.length;
    findFrequency(arr, n);
    
  }
}