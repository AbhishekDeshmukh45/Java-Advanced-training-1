package program6_3;

public class Employee {


		  private String empno;
		    private String name;
		    private String empaddress;
		    
		 
		    public Employee(String empno, String name,String empaddress) { // constructor
		           this.empno = empno;
		           this.name = name;
		           this.empaddress=empaddress;
		    }
		 
		    @Override
		    public String toString() {
		           return "Employee [empno=" + empno + ", name=" + name + " ,address ="+empaddress+ "]  ";
		    }
		    
		}
		 
		
		 
		class LinkedListEmptyException extends RuntimeException{
		       public LinkedListEmptyException(){
		         super();
		       }
		      
		     public LinkedListEmptyException(String message){
		         super(message);
		       }  
		}
		  
		class Node<T> {
		    public T data; 
		    public Node<T> next; 
		 
		     
		   
		    public Node(T data){
		           this.data = data;
		    }
		  
		    
		    public void displayNode() {
		           System.out.print( data + " ");
		    }
		}

		
		 
		class LinkedList<T> {
		    private Node<T> first; 
		 
		 LinkedList(){
		           first = null;
		    }
		 
		    public void insertFirst(T data) {
		           Node<T> newNode = new Node<T>(data);  
		           newNode.next = first;   
		           first = newNode;  
		    }
		    
		   
		    
		    public void displayLinkedList() {
		           System.out.print("Displaying LinkedList [first--->last]: ");
		           Node<T> tempDisplay = first; 
		           while (tempDisplay != null){ 
		                  tempDisplay.displayNode();
		                  tempDisplay = tempDisplay.next; 
		           }
		           System.out.println();
		           
		    }
		 
		}